AutoGroup Local Plugin
*********************

Automatically assigned enrolled users on a course into groups
dependant upon information within their user profile

Changelog
**********
v1.0   - Stable release. Tested for compatability with Moodle 2.7 and 2.8

Install
**********

Copy the plugin directory "autogroup" into moodle\local\.
Check admin notifications to install.

Maintainer
**********

The plugin has been written and is being maintained by Mark Ward (me@moodlemark.com)

Thanks to
**********

Development for v1 of the plugin was funded by East Central BOCES (http://www.ecboces.org/)

Many ideas and suggestions for the functionality of the plugin were contributed
by Emma Richardson at East Central BOCES.

Contact
*******

http://moodle.org/user/profile.php?id=489101
http://moodlemark.com
https://www.github.com/markward


License
*******

Released Under the GNU General Public Licence http://www.gnu.org/copyleft/gpl.html